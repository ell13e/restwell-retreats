<?php
/**
 * Restwell Retreats theme functions and definitions.
 *
 * @package Restwell_Retreats
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Disable Gutenberg block editor — use classic editor
add_filter( 'use_block_editor_for_post', '__return_false' );
add_filter( 'use_widgets_block_editor', '__return_false' );

require_once get_template_directory() . '/inc/meta-fields.php';
require_once get_template_directory() . '/inc/theme-setup.php';

/**
 * Enqueue scripts and styles.
 */
function restwell_enqueue_scripts() {
	$theme_uri = get_template_directory_uri();

	wp_enqueue_style(
		'restwell-style',
		$theme_uri . '/assets/css/style.css',
		array(),
		wp_get_theme()->get( 'Version' )
	);

	wp_enqueue_script(
		'restwell-main',
		$theme_uri . '/assets/js/main.js',
		array(),
		wp_get_theme()->get( 'Version' ),
		true
	);
}
add_action( 'wp_enqueue_scripts', 'restwell_enqueue_scripts' );

/**
 * Declare theme support.
 */
function restwell_theme_setup() {
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'title-tag' );
	add_theme_support(
		'html5',
		array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
			'style',
			'script',
		)
	);
}
add_action( 'after_setup_theme', 'restwell_theme_setup' );
