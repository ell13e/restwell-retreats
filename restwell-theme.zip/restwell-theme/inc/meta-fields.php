<?php
/**
 * Page Content Fields — meta box for front page structured content.
 * WordPress core only; no plugins.
 *
 * @package Restwell_Retreats
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const RESTWELL_META_NONCE_ACTION = 'restwell_page_content_fields_save';
const RESTWELL_META_NONCE_NAME   = 'restwell_page_content_fields_nonce';

/**
 * Register meta box "Page Content Fields" for pages.
 */
function restwell_register_page_content_meta_box() {
	add_meta_box(
		'restwell_page_content_fields',
		__( 'Page Content Fields', 'restwell-retreats' ),
		'restwell_page_content_meta_box_callback',
		'page',
		'normal',
		'high'
	);
}
add_action( 'add_meta_boxes', 'restwell_register_page_content_meta_box' );

/**
 * Meta box callback: output all input fields grouped by section.
 */
function restwell_page_content_meta_box_callback( $post ) {
	wp_nonce_field( RESTWELL_META_NONCE_ACTION, RESTWELL_META_NONCE_NAME );

	$fields = restwell_get_page_content_field_definitions();
	$current = get_post_meta( $post->ID, '', true );

	echo '<div class="restwell-meta-fields" style="display:grid;gap:1.5rem;">';

	foreach ( $fields as $section => $items ) {
		echo '<fieldset style="border:1px solid #c3c4c7;padding:1rem;border-radius:4px;">';
		echo '<legend style="font-weight:600;">' . esc_html( $section ) . '</legend>';
		echo '<div style="display:grid;gap:0.75rem;">';

		foreach ( $items as $key => $label ) {
			$value = isset( $current[ $key ][0] ) ? $current[ $key ][0] : '';
			$id    = 'restwell_' . $key;
			$name  = $key;

			if ( $key === 'meta_description' || strpos( $key, '_body' ) !== false || strpos( $key, '_desc' ) !== false ) {
				echo '<label for="' . esc_attr( $id ) . '" style="display:block;font-weight:500;">' . esc_html( $label ) . '</label>';
				echo '<textarea id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" rows="3" style="width:100%;">' . esc_textarea( $value ) . '</textarea>';
			} elseif ( strpos( $key, '_image_id' ) !== false ) {
				echo '<label for="' . esc_attr( $id ) . '" style="display:block;font-weight:500;">' . esc_html( $label ) . ' (Attachment ID)</label>';
				echo '<input type="number" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '" min="0" step="1" style="width:100%;max-width:8rem;" />';
			} else {
				echo '<label for="' . esc_attr( $id ) . '" style="display:block;font-weight:500;">' . esc_html( $label ) . '</label>';
				echo '<input type="text" id="' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $value ) . '" style="width:100%;" />';
			}
		}
		echo '</div></fieldset>';
	}

	echo '</div>';
}

/**
 * Field definitions: section => [ meta_key => label ].
 */
function restwell_get_page_content_field_definitions() {
	return array(
		'SEO' => array(
			'meta_description' => 'Meta description (for search engines)',
		),
		'Hero' => array(
			'hero_eyebrow'            => 'Hero eyebrow label',
			'hero_heading'            => 'Hero heading (h1)',
			'hero_subheading'         => 'Hero subheading',
			'hero_cta_primary_label'  => 'Hero primary button label',
			'hero_cta_primary_url'    => 'Hero primary button URL',
			'hero_cta_secondary_label'=> 'Hero secondary button label',
			'hero_cta_secondary_url'  => 'Hero secondary button URL',
		),
		'What is Restwell?' => array(
			'what_restwell_label'   => 'Section label',
			'what_restwell_heading' => 'Section heading (h2)',
			'intro_body'            => 'Intro body (paragraph)',
		),
		'Who it\'s for' => array(
			'who_label'        => 'Section label',
			'who_heading'      => 'Section heading (h2)',
			'who_guest_title'  => 'Guest card title',
			'who_guest_body'   => 'Guest card body',
			'who_carer_title'  => 'Carer card title',
			'who_carer_body'   => 'Carer card body',
		),
		'Property snapshot' => array(
			'property_label'      => 'Section label',
			'property_heading'   => 'Section heading (e.g. 101 Russell Drive)',
			'property_body'      => 'Property body copy',
			'property_cta_label' => 'CTA link label',
			'property_cta_url'   => 'CTA link URL',
			'property_image_id'  => 'Property image (attachment ID)',
		),
		'Why Restwell?' => array(
			'why_label'       => 'Section label',
			'why_heading'     => 'Section heading (h2)',
			'why_item1_title' => 'Item 1 title',
			'why_item1_desc'   => 'Item 1 description',
			'why_item2_title' => 'Item 2 title',
			'why_item2_desc'   => 'Item 2 description',
			'why_item3_title' => 'Item 3 title',
			'why_item3_desc'   => 'Item 3 description',
			'why_item4_title' => 'Item 4 title',
			'why_item4_desc'   => 'Item 4 description',
		),
		'CTA section' => array(
			'cta_heading'         => 'CTA heading (h2)',
			'cta_body'            => 'CTA body copy',
			'cta_primary_label'   => 'CTA primary button label',
			'cta_primary_url'     => 'CTA primary button URL',
			'cta_secondary_label' => 'CTA secondary button label',
			'cta_secondary_url'   => 'CTA secondary button URL',
			'cta_image_id'        => 'CTA background image (attachment ID)',
		),
	);
}

/**
 * Save meta box: verify nonce and sanitize all fields.
 */
function restwell_save_page_content_meta_box( $post_id ) {
	if ( ! isset( $_POST[ RESTWELL_META_NONCE_NAME ] ) ||
	     ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST[ RESTWELL_META_NONCE_NAME ] ) ), RESTWELL_META_NONCE_ACTION ) ) {
		return;
	}
	if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
		return;
	}
	if ( ! current_user_can( 'edit_post', $post_id ) ) {
		return;
	}

	$fields = restwell_get_page_content_field_definitions();
	foreach ( $fields as $items ) {
		foreach ( array_keys( $items ) as $key ) {
			if ( ! isset( $_POST[ $key ] ) ) {
				continue;
			}
			$raw = wp_unslash( $_POST[ $key ] );
			if ( strpos( $key, '_image_id' ) !== false ) {
				$value = absint( $raw );
			} elseif ( $key === 'meta_description' || strpos( $key, '_body' ) !== false || strpos( $key, '_desc' ) !== false ) {
				$value = sanitize_textarea_field( $raw );
			} else {
				$value = sanitize_text_field( $raw );
			}
			update_post_meta( $post_id, $key, $value );
		}
	}
}
add_action( 'save_post_page', 'restwell_save_page_content_meta_box' );
