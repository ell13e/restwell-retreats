<?php
/**
 * Theme setup: WP Admin page to create pages and seed front page meta.
 *
 * @package Restwell_Retreats
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

const RESTWELL_SETUP_NONCE_ACTION = 'restwell_theme_setup_run';
const RESTWELL_SETUP_NONCE_NAME   = 'restwell_theme_setup_nonce';

/**
 * Pages to create: title => slug.
 */
function restwell_get_theme_setup_pages() {
	return array(
		'Home'           => 'home',
		'The Property'   => 'the-property',
		'How It Works'   => 'how-it-works',
		'Why Restwell?'  => 'why-restwell',
		'Accessibility'  => 'accessibility',
		'FAQ'            => 'faq',
		'Enquire'        => 'enquire',
	);
}

/**
 * Default meta values for the front page (Home).
 */
function restwell_get_theme_setup_defaults() {
	return array(
		'hero_eyebrow'             => 'Accessible holidays in Whitstable',
		'hero_heading'             => 'Rest easy. A real holiday for both of you.',
		'hero_subheading'          => 'A beautiful, accessible home on the Kent coast — where guests find adventure and carers find a true break.',
		'hero_cta_primary_label'   => 'See the property',
		'hero_cta_primary_url'     => '/property',
		'hero_cta_secondary_label' => 'Check availability',
		'hero_cta_secondary_url'   => '/enquire',

		'what_restwell_label'   => 'What is Restwell Retreats?',
		'what_restwell_heading' => 'A holiday, not a care home.',
		'intro_body'            => 'Restwell Retreats is a high-quality, accessible holiday let in Whitstable, Kent. This is not a care home or a clinical facility. It is a proper coastal holiday — with the option of professional, CQC-regulated care support on hand through our partner, Continuity of Care Services. Whether you need a morning check-in or more comprehensive support, it is there if you want it. And if you don\'t, you simply enjoy the house, the coast, and the freedom.',

		'who_label'        => "Who it's for",
		'who_heading'      => 'Two people. One break.',
		'who_guest_title'  => 'For the guest',
		'who_guest_body'   => "A space designed around you. Wide doorways, level access, and the freedom to explore Whitstable's vibrant coast at your own pace. This is your holiday — not an appointment, not a schedule. Just the sea air, good food, and a comfortable home to come back to.",
		'who_carer_title'  => 'For the carer',
		'who_carer_body'   => 'Peace of mind is the ultimate luxury. With optional professional support available from CCS, you can step back, relax, and enjoy being a partner, a parent, or a friend again — rather than a full-time carer. Rest easy knowing they are safe, happy, and having a proper break too.',

		'property_label'      => 'Our Whitstable home',
		'property_heading'   => '101 Russell Drive',
		'property_body'      => "Our flagship property sits in a quiet residential corner of Whitstable, just a short, flat walk from the famous Tankerton Slopes promenade. It is the perfect base for exploring everything this charming coastal town has to offer — from Harbour Street's independent shops to fresh oysters by the water.",
		'property_cta_label' => 'Explore the property',
		'property_cta_url'   => '/property',
		'property_image_id'  => 0,

		'why_label'       => 'Why Restwell?',
		'why_heading'     => 'What makes us different',
		'why_item1_title' => 'Private & personal',
		'why_item1_desc'  => 'A real home, not a ward or a hotel room. The whole house is yours.',
		'why_item2_title' => 'Expertly supported',
		'why_item2_desc'  => 'Optional CQC-regulated care from Continuity of Care Services.',
		'why_item3_title' => 'Whitstable local',
		'why_item3_desc'  => 'We know the best accessible spots, the quietest cafes, and the flattest routes.',
		'why_item4_title' => 'Honest & open',
		'why_item4_desc'  => 'We tell you exactly what to expect — no surprises, no overselling.',

		'cta_heading'          => 'Ready to plan your break?',
		'cta_body'            => 'Whether you have dates in mind or just want to ask a question, we are here to help. No pressure, just a conversation.',
		'cta_primary_label'   => 'See the property',
		'cta_primary_url'     => '/property',
		'cta_secondary_label' => 'Enquire now',
		'cta_secondary_url'   => '/enquire',
		'cta_image_id'        => 0,
	);
}

/**
 * Add Theme Setup under Appearance.
 */
function restwell_theme_setup_admin_menu() {
	add_theme_page(
		__( 'Theme Setup', 'restwell-retreats' ),
		__( 'Theme Setup', 'restwell-retreats' ),
		'manage_options',
		'restwell-theme-setup',
		'restwell_theme_setup_page'
	);
}
add_action( 'admin_menu', 'restwell_theme_setup_admin_menu' );

/**
 * Render the Theme Setup admin page and handle POST.
 */
function restwell_theme_setup_page() {
	if ( ! current_user_can( 'manage_options' ) ) {
		wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'restwell-retreats' ) );
	}

	$message = '';
	$already_seeded = restwell_theme_setup_is_seeded();

	// Handle form submission.
	if ( isset( $_POST[ RESTWELL_SETUP_NONCE_NAME ] ) && isset( $_POST['restwell_run_setup'] ) ) {
		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST[ RESTWELL_SETUP_NONCE_NAME ] ) ), RESTWELL_SETUP_NONCE_ACTION ) ) {
			$message = '<div class="notice notice-error"><p>' . esc_html__( 'Security check failed. Please try again.', 'restwell-retreats' ) . '</p></div>';
		} else {
			$force = ! empty( $_POST['restwell_rerun'] );
			$result = restwell_run_theme_setup( $force );
			$message = restwell_theme_setup_format_message( $result );
		}
	}

	?>
	<div class="wrap">
		<h1><?php esc_html_e( 'Restwell Theme Setup', 'restwell-retreats' ); ?></h1>

		<?php echo $message; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped — built from escaped fragments ?>

		<div class="notice notice-warning">
			<p><?php esc_html_e( 'This will create all pages and populate default content. Only run this once on a fresh install.', 'restwell-retreats' ); ?></p>
		</div>

		<?php if ( $already_seeded ) : ?>
			<div class="notice notice-info">
				<p><?php esc_html_e( 'Setup already completed.', 'restwell-retreats' ); ?></p>
			</div>
		<?php endif; ?>

		<form method="post" action="">
			<?php wp_nonce_field( RESTWELL_SETUP_NONCE_ACTION, RESTWELL_SETUP_NONCE_NAME ); ?>
			<?php if ( $already_seeded ) : ?>
				<p>
					<label>
						<input type="checkbox" name="restwell_rerun" value="1" />
						<?php esc_html_e( 'Re-run setup anyway', 'restwell-retreats' ); ?>
					</label>
				</p>
			<?php endif; ?>
			<p>
				<button type="submit" name="restwell_run_setup" value="1" class="button button-primary">
					<?php esc_html_e( 'Run Theme Setup', 'restwell-retreats' ); ?>
				</button>
			</p>
		</form>
	</div>
	<?php
}

/**
 * Check if front page has been seeded (setup already run).
 */
function restwell_theme_setup_is_seeded() {
	$page_id = (int) get_option( 'page_on_front', 0 );
	if ( $page_id < 1 ) {
		return false;
	}
	return get_post_meta( $page_id, 'restwell_fields_seeded', true ) === '1';
}

/**
 * Run theme setup: create pages, set front page, seed Home meta.
 *
 * @param bool $force If true, re-seed Home meta even if already seeded.
 * @return array{ 'created': string[], 'skipped': string[], 'front_page_set': bool, 'home_seeded': bool }
 */
function restwell_run_theme_setup( $force = false ) {
	$result = array(
		'created'       => array(),
		'skipped'       => array(),
		'front_page_set' => false,
		'home_seeded'   => false,
	);

	$pages = restwell_get_theme_setup_pages();
	$created_ids = array();

	foreach ( $pages as $title => $slug ) {
		$existing = get_page_by_path( $slug, OBJECT, 'page' );
		if ( $existing ) {
			$result['skipped'][] = $title;
			$created_ids[ $title ] = $existing->ID;
		} else {
			$id = wp_insert_post(
				array(
					'post_title'   => $title,
					'post_name'    => $slug,
					'post_status'  => 'publish',
					'post_type'    => 'page',
					'post_author'  => get_current_user_id(),
				),
				true
			);
			if ( ! is_wp_error( $id ) ) {
				$result['created'][] = $title;
				$created_ids[ $title ] = $id;
			}
		}
	}

	$home_id = isset( $created_ids['Home'] ) ? (int) $created_ids['Home'] : 0;
	if ( $home_id < 1 ) {
		$home_page = get_page_by_path( 'home', OBJECT, 'page' );
		$home_id   = $home_page ? (int) $home_page->ID : 0;
	}

	if ( $home_id > 0 ) {
		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $home_id );
		$result['front_page_set'] = true;

		$should_seed = $force || get_post_meta( $home_id, 'restwell_fields_seeded', true ) !== '1';
		if ( $should_seed ) {
			$defaults = restwell_get_theme_setup_defaults();
			foreach ( $defaults as $key => $value ) {
				update_post_meta( $home_id, $key, $value );
			}
			update_post_meta( $home_id, 'restwell_fields_seeded', '1' );
			$result['home_seeded'] = true;
		}
	}

	return $result;
}

/**
 * Format setup result as an admin notice.
 *
 * @param array $result Result from restwell_run_theme_setup().
 * @return string HTML for the notice.
 */
function restwell_theme_setup_format_message( $result ) {
	$lines = array();

	if ( ! empty( $result['created'] ) ) {
		$lines[] = '<strong>' . esc_html__( 'Created pages:', 'restwell-retreats' ) . '</strong> ' . esc_html( implode( ', ', $result['created'] ) );
	}
	if ( ! empty( $result['skipped'] ) ) {
		$lines[] = '<strong>' . esc_html__( 'Skipped (already exist):', 'restwell-retreats' ) . '</strong> ' . esc_html( implode( ', ', $result['skipped'] ) );
	}
	if ( $result['front_page_set'] ) {
		$lines[] = esc_html__( 'Home set as static front page.', 'restwell-retreats' );
	}
	if ( $result['home_seeded'] ) {
		$lines[] = esc_html__( 'Default content seeded on Home page.', 'restwell-retreats' );
	}

	if ( empty( $lines ) ) {
		return '<div class="notice notice-warning"><p>' . esc_html__( 'No changes made. Home page may be missing.', 'restwell-retreats' ) . '</p></div>';
	}

	return '<div class="notice notice-success"><p>' . implode( '<br />', $lines ) . '</p></div>';
}
