<?php
/**
 * Footer template.
 * Translated from client/src/components/Footer.tsx.
 *
 * @package Restwell_Retreats
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<footer class="site-footer" role="contentinfo">
	<div class="container">
		<div class="footer-grid">
			<!-- Brand -->
			<div class="footer-brand">
				<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="site-logo" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?> home">
					<span class="logo-icon">
						<svg width="44" height="24" viewBox="0 0 80 44" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img">
							<path d="M40 22 C40 22 32 6 20 6 C10.5 6 4 13 4 22 C4 31 10.5 38 20 38 C32 38 40 22 40 22 C40 22 48 6 60 6 C69.5 6 76 13 76 22 C76 31 69.5 38 60 38 C48 38 40 22 40 22Z" fill="#F5EDE0"/>
						</svg>
					</span>
					<span class="logo-text">
						<span class="site-name"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></span>
						<span class="tagline">REST EASY.</span>
					</span>
				</a>
				<p class="footer-description">A <?php echo esc_html( get_bloginfo( 'name' ) ); ?> property, by Continuity of Care Services.</p>
				<p class="footer-description">Care provided by Continuity of Care Services.</p>
			</div>

			<!-- Explore -->
			<div class="footer-explore">
				<h3 class="footer-heading">Explore</h3>
				<nav aria-label="Footer navigation">
					<ul class="footer-nav-list">
						<li><a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a></li>
						<li><a href="#">The Property</a></li>
						<li><a href="#">How It Works</a></li>
						<li><a href="#">Why Restwell?</a></li>
						<li><a href="#">Accessibility</a></li>
						<li><a href="#">FAQ</a></li>
						<li><a href="#">Enquire</a></li>
					</ul>
				</nav>
			</div>

			<!-- Get in Touch -->
			<div class="footer-contact">
				<h3 class="footer-heading">Get in Touch</h3>
				<p><strong>Email:</strong> <em>PLACEHOLDER – Email to be confirmed</em></p>
				<p><strong>Phone:</strong> <em>PLACEHOLDER – Phone to be confirmed</em></p>
				<p><em>PLACEHOLDER – Social links</em></p>
			</div>
		</div>

		<div class="site-footer__bottom">
			<p class="site-footer__copyright">&copy; <?php echo esc_html( date( 'Y' ) ); ?> Restwell Retreats. All rights reserved.</p>
		</div>
	</div>
	<?php wp_footer(); ?>
</footer>
</body>
</html>
