<?php
/**
 * Front Page template.
 * Uses Page Content Fields meta (get_post_meta) and featured/attachment images.
 * WordPress core only.
 *
 * @package Restwell_Retreats
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

get_header();

$pid = get_the_ID();
$hero_eyebrow            = get_post_meta( $pid, 'hero_eyebrow', true ) ?: 'Accessible holidays in Whitstable';
$hero_heading            = get_post_meta( $pid, 'hero_heading', true ) ?: 'Rest easy. A real holiday for both of you.';
$hero_subheading         = get_post_meta( $pid, 'hero_subheading', true ) ?: 'A beautiful, accessible home on the Kent coast — where guests find adventure and carers find a true break.';
$hero_cta_primary_label  = get_post_meta( $pid, 'hero_cta_primary_label', true ) ?: 'See the property';
$hero_cta_primary_url    = get_post_meta( $pid, 'hero_cta_primary_url', true ) ?: '/property';
$hero_cta_secondary_label= get_post_meta( $pid, 'hero_cta_secondary_label', true ) ?: 'Check availability';
$hero_cta_secondary_url  = get_post_meta( $pid, 'hero_cta_secondary_url', true ) ?: '/contact';

$what_label   = get_post_meta( $pid, 'what_restwell_label', true ) ?: 'What is Restwell Retreats?';
$what_heading = get_post_meta( $pid, 'what_restwell_heading', true ) ?: 'A holiday, not a care home.';

$who_label   = get_post_meta( $pid, 'who_label', true ) ?: 'Who it\'s for';
$who_heading = get_post_meta( $pid, 'who_heading', true ) ?: 'Two people. One break.';
$who_guest_title = get_post_meta( $pid, 'who_guest_title', true ) ?: 'For the guest';
$who_guest_body  = get_post_meta( $pid, 'who_guest_body', true ) ?: 'A space designed around you. Wide doorways, level access, and the freedom to explore Whitstable\'s vibrant coast at your own pace. This is your holiday — not an appointment, not a schedule. Just the sea air, good food, and a comfortable home to come back to.';
$who_carer_title = get_post_meta( $pid, 'who_carer_title', true ) ?: 'For the carer';
$who_carer_body  = get_post_meta( $pid, 'who_carer_body', true ) ?: 'Peace of mind is the ultimate luxury. With optional professional support available from CCS, you can step back, relax, and enjoy being a partner, a parent, or a friend again — rather than a full-time carer. Rest easy knowing they are safe, happy, and having a proper break too.';

$property_label    = get_post_meta( $pid, 'property_label', true ) ?: 'Our Whitstable home';
$property_heading  = get_post_meta( $pid, 'property_heading', true ) ?: '101 Russell Drive';
$property_body     = get_post_meta( $pid, 'property_body', true ) ?: 'Our flagship property sits in a quiet residential corner of Whitstable, just a short, flat walk from the famous Tankerton Slopes promenade. It is the perfect base for exploring everything this charming coastal town has to offer — from Harbour Street\'s independent shops to fresh oysters by the water.';
$property_cta_label = get_post_meta( $pid, 'property_cta_label', true ) ?: 'Explore the property';
$property_cta_url  = get_post_meta( $pid, 'property_cta_url', true ) ?: '/property';
$property_image_id = (int) get_post_meta( $pid, 'property_image_id', true );

$why_label   = get_post_meta( $pid, 'why_label', true ) ?: 'Why Restwell?';
$why_heading = get_post_meta( $pid, 'why_heading', true ) ?: 'What makes us different';
$why1_title  = get_post_meta( $pid, 'why_item1_title', true ) ?: 'Private & personal';
$why1_desc   = get_post_meta( $pid, 'why_item1_desc', true ) ?: 'A real home, not a ward or a hotel room. The whole house is yours.';
$why2_title  = get_post_meta( $pid, 'why_item2_title', true ) ?: 'Expertly supported';
$why2_desc   = get_post_meta( $pid, 'why_item2_desc', true ) ?: 'Optional CQC-regulated care from Continuity of Care Services.';
$why3_title  = get_post_meta( $pid, 'why_item3_title', true ) ?: 'Whitstable local';
$why3_desc   = get_post_meta( $pid, 'why_item3_desc', true ) ?: 'We know the best accessible spots, the quietest cafes, and the flattest routes.';
$why4_title  = get_post_meta( $pid, 'why_item4_title', true ) ?: 'Honest & open';
$why4_desc   = get_post_meta( $pid, 'why_item4_desc', true ) ?: 'We tell you exactly what to expect — no surprises, no overselling.';

$cta_heading   = get_post_meta( $pid, 'cta_heading', true ) ?: 'Ready to plan your break?';
$cta_body      = get_post_meta( $pid, 'cta_body', true ) ?: 'Whether you have dates in mind or just want to ask a question, we are here to help. No pressure, just a conversation.';
$cta_primary_label   = get_post_meta( $pid, 'cta_primary_label', true ) ?: 'See the property';
$cta_primary_url     = get_post_meta( $pid, 'cta_primary_url', true ) ?: '/property';
$cta_secondary_label = get_post_meta( $pid, 'cta_secondary_label', true ) ?: 'Enquire now';
$cta_secondary_url   = get_post_meta( $pid, 'cta_secondary_url', true ) ?: '/contact';
$cta_image_id = (int) get_post_meta( $pid, 'cta_image_id', true );

$hero_thumb_id = get_post_thumbnail_id( $pid );
$hero_src     = $hero_thumb_id ? wp_get_attachment_image_url( $hero_thumb_id, 'full' ) : '';
$property_src = $property_image_id ? wp_get_attachment_image_url( $property_image_id, 'full' ) : '';
$cta_src      = $cta_image_id ? wp_get_attachment_image_url( $cta_image_id, 'full' ) : '';
$hero_fallback = get_template_directory_uri() . '/assets/images/hero-coastal.jpg';
$hero_bg_url  = $hero_src ? $hero_src : $hero_fallback;
?>
<main class="flex-1" id="main-content">
	<!-- Hero Section -->
	<!-- HERO IMAGE: copy hero-coastal.jpg to /restwell-theme/assets/images/ (beach huts photo from Home.tsx IMAGES.heroCoastal) -->
	<section class="hero relative flex items-end overflow-hidden" style="background-image: url('<?php echo esc_url( $hero_bg_url ); ?>');">
		<?php if ( $hero_src ) : ?>
			<img
				src="<?php echo esc_url( $hero_src ); ?>"
				alt="<?php echo esc_attr( $hero_heading ); ?>"
				class="absolute inset-0 w-full h-full object-cover"
			/>
		<?php endif; ?>
		<div class="absolute inset-0 bg-gradient-to-t from-[#1B4D5C]/80 via-[#1B4D5C]/30 to-transparent"></div>
		<div class="relative container pb-16 md:pb-24 pt-32">
			<div class="max-w-2xl">
				<p class="text-[#D4A853] text-sm font-semibold uppercase tracking-[0.2em] mb-4" style="font-family: 'Inter', sans-serif">
					<?php echo esc_html( $hero_eyebrow ); ?>
				</p>
				<h1 class="text-white text-4xl md:text-5xl lg:text-6xl mb-6 leading-tight">
					<?php echo esc_html( $hero_heading ); ?>
				</h1>
				<p class="text-[#F5EDE0] text-lg md:text-xl mb-8 leading-relaxed max-w-lg">
					<?php echo esc_html( $hero_subheading ); ?>
				</p>
				<div class="flex flex-wrap gap-4">
					<a
						href="<?php echo esc_url( $hero_cta_primary_url ); ?>"
						class="inline-flex items-center gap-2 bg-[#D4A853] text-[#1B4D5C] font-semibold px-6 py-3 rounded-full hover:bg-[#c49a48] transition-colors duration-300 no-underline text-base"
					>
						<?php echo esc_html( $hero_cta_primary_label ); ?>
						<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
					</a>
					<a
						href="<?php echo esc_url( $hero_cta_secondary_url ); ?>"
						class="inline-flex items-center gap-2 bg-white/15 backdrop-blur-sm text-white font-medium px-6 py-3 rounded-full border border-white/30 hover:bg-white/25 transition-colors duration-300 no-underline text-base"
					>
						<?php echo esc_html( $hero_cta_secondary_label ); ?>
					</a>
				</div>
			</div>
		</div>
	</section>

	<!-- What is Restwell Retreats? -->
	<section class="intro-section py-20 md:py-28">
		<div class="container">
			<div class="max-w-3xl mx-auto text-center">
				<span class="text-[#D4A853] text-sm font-semibold uppercase tracking-[0.2em] block mb-4 section-label" style="font-family: 'Inter', sans-serif">
					<?php echo esc_html( $what_label ); ?>
				</span>
				<h2 class="text-3xl md:text-4xl mb-8 section-heading"><?php echo esc_html( $what_heading ); ?></h2>
				<?php
				$intro_body = get_post_meta( get_the_ID(), 'intro_body', true );
				if ( $intro_body ) {
					echo '<p class="text-lg">' . wp_kses_post( $intro_body ) . '</p>';
				}
				?>
			</div>
		</div>
	</section>

	<!-- Who It's For — Dual Audience Cards -->
	<section class="who-section py-16 md:py-24 bg-white">
		<div class="container">
			<div class="text-center mb-12">
				<span class="text-[#D4A853] text-sm font-semibold uppercase tracking-[0.2em] block mb-4 section-label" style="font-family: 'Inter', sans-serif">
					<?php echo esc_html( $who_label ); ?>
				</span>
				<h2 class="text-3xl md:text-4xl section-heading"><?php echo esc_html( $who_heading ); ?></h2>
			</div>
			<div class="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
				<div class="who-card bg-[#F5EDE0] rounded-2xl p-8 md:p-10 space-y-4">
					<div class="w-12 h-12 bg-[#A8D5D0]/30 rounded-xl flex items-center justify-center">
						<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#1B4D5C" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
					</div>
					<h3 class="text-xl"><?php echo esc_html( $who_guest_title ); ?></h3>
					<p class="text-[#3a5a63] leading-relaxed"><?php echo esc_html( $who_guest_body ); ?></p>
				</div>
				<div class="who-card bg-[#F5EDE0] rounded-2xl p-8 md:p-10 space-y-4">
					<div class="w-12 h-12 bg-[#D4A853]/20 rounded-xl flex items-center justify-center">
						<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#D4A853" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg>
					</div>
					<h3 class="text-xl"><?php echo esc_html( $who_carer_title ); ?></h3>
					<p class="text-[#3a5a63] leading-relaxed"><?php echo esc_html( $who_carer_body ); ?></p>
				</div>
			</div>
		</div>
	</section>

	<!-- Property Snapshot -->
	<section class="property-section py-16 md:py-24">
		<div class="container">
			<div class="property-grid grid gap-8 items-center">
				<div class="property-grid__image rounded-2xl overflow-hidden shadow-lg">
					<?php if ( $property_src ) : ?>
						<img
							src="<?php echo esc_url( $property_src ); ?>"
							alt="<?php echo esc_attr( $property_heading ); ?>"
							class="w-full h-[350px] md:h-[450px] object-cover"
						/>
					<?php else : ?>
						<!-- PROPERTY IMAGE NEEDED -->
						<div class="property-placeholder" style="width:100%; height:350px; background:#E8DFD0; display:flex; align-items:center; justify-content:center; color:#8B8B7A;">Add property image</div>
					<?php endif; ?>
				</div>
				<div class="property-grid__text space-y-6">
					<span class="text-[#D4A853] text-sm font-semibold uppercase tracking-[0.2em]" style="font-family: 'Inter', sans-serif">
						<?php echo esc_html( $property_label ); ?>
					</span>
					<h2 class="text-3xl"><?php echo esc_html( $property_heading ); ?></h2>
					<p class="text-[#3a5a63] leading-relaxed"><?php echo esc_html( $property_body ); ?></p>
					<a
						href="<?php echo esc_url( $property_cta_url ); ?>"
						class="inline-flex items-center gap-2 text-[#1B4D5C] font-semibold hover:text-[#D4A853] transition-colors duration-300 no-underline"
					>
						<?php echo esc_html( $property_cta_label ); ?>
						<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>
					</a>
				</div>
			</div>
		</div>
	</section>

	<!-- Why Restwell? Mini -->
	<section class="features-section py-16 md:py-24 bg-white">
		<div class="container">
			<div class="text-center mb-12">
				<span class="text-[#D4A853] text-sm font-semibold uppercase tracking-[0.2em] block mb-4 section-label" style="font-family: 'Inter', sans-serif">
					<?php echo esc_html( $why_label ); ?>
				</span>
				<h2 class="text-3xl md:text-4xl section-heading"><?php echo esc_html( $why_heading ); ?></h2>
			</div>
			<div class="features-grid grid gap-6 max-w-5xl mx-auto">
				<div class="feature-item text-center space-y-3 p-6">
					<div class="w-11 h-11 bg-[#A8D5D0]/25 rounded-xl flex items-center justify-center mx-auto text-[#1B4D5C]">
						<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
					</div>
					<h3 class="text-lg"><?php echo esc_html( $why1_title ); ?></h3>
					<p class="text-sm text-[#3a5a63] leading-relaxed"><?php echo esc_html( $why1_desc ); ?></p>
				</div>
				<div class="feature-item text-center space-y-3 p-6">
					<div class="w-11 h-11 bg-[#A8D5D0]/25 rounded-xl flex items-center justify-center mx-auto text-[#1B4D5C]">
						<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
					</div>
					<h3 class="text-lg"><?php echo esc_html( $why2_title ); ?></h3>
					<p class="text-sm text-[#3a5a63] leading-relaxed"><?php echo esc_html( $why2_desc ); ?></p>
				</div>
				<div class="feature-item text-center space-y-3 p-6">
					<div class="w-11 h-11 bg-[#A8D5D0]/25 rounded-xl flex items-center justify-center mx-auto text-[#1B4D5C]">
						<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
					</div>
					<h3 class="text-lg"><?php echo esc_html( $why3_title ); ?></h3>
					<p class="text-sm text-[#3a5a63] leading-relaxed"><?php echo esc_html( $why3_desc ); ?></p>
				</div>
				<div class="feature-item text-center space-y-3 p-6">
					<div class="w-11 h-11 bg-[#A8D5D0]/25 rounded-xl flex items-center justify-center mx-auto text-[#1B4D5C]">
						<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"></path></svg>
					</div>
					<h3 class="text-lg"><?php echo esc_html( $why4_title ); ?></h3>
					<p class="text-sm text-[#3a5a63] leading-relaxed"><?php echo esc_html( $why4_desc ); ?></p>
				</div>
			</div>
		</div>
	</section>

	<!-- CTA Section -->
	<section class="relative py-20 md:py-28 overflow-hidden">
		<?php if ( $cta_src ) : ?>
			<img
				src="<?php echo esc_url( $cta_src ); ?>"
				alt=""
				class="absolute inset-0 w-full h-full object-cover"
				role="presentation"
			/>
		<?php else : ?>
			<!-- IMAGE NEEDED: CTA background (set cta_image_id in Page Content Fields) -->
		<?php endif; ?>
		<div class="absolute inset-0 bg-[#1B4D5C]/75"></div>
		<div class="relative container text-center">
			<h2 class="text-white text-3xl md:text-4xl mb-4"><?php echo esc_html( $cta_heading ); ?></h2>
			<p class="text-[#A8D5D0] text-lg mb-8 max-w-lg mx-auto">
				<?php echo esc_html( $cta_body ); ?>
			</p>
			<div class="flex flex-wrap justify-center gap-4">
				<a
					href="<?php echo esc_url( $cta_primary_url ); ?>"
					class="inline-flex items-center gap-2 bg-[#D4A853] text-[#1B4D5C] font-semibold px-6 py-3 rounded-full hover:bg-[#c49a48] transition-colors duration-300 no-underline"
				>
					<?php echo esc_html( $cta_primary_label ); ?>
				</a>
				<a
					href="<?php echo esc_url( $cta_secondary_url ); ?>"
					class="inline-flex items-center gap-2 bg-white/15 backdrop-blur-sm text-white font-medium px-6 py-3 rounded-full border border-white/30 hover:bg-white/25 transition-colors duration-300 no-underline"
				>
					<?php echo esc_html( $cta_secondary_label ); ?>
				</a>
			</div>
		</div>
	</section>
</main>
<?php get_footer(); ?>
