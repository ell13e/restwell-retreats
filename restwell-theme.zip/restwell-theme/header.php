<?php
/**
 * Header template.
 * Translated from client/src/components/Header.tsx.
 *
 * @package Restwell_Retreats
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<?php
	// Meta description: page meta or fallback to site tagline
	$meta_desc = '';
	if ( is_singular() ) {
		$meta_desc = get_post_meta( get_queried_object_id(), 'meta_description', true );
	}
	if ( $meta_desc === '' ) {
		$meta_desc = get_bloginfo( 'description' );
	}
	if ( $meta_desc !== '' ) {
		echo '<meta name="description" content="' . esc_attr( $meta_desc ) . '">' . "\n";
	}
	// Canonical URL
	if ( is_front_page() ) {
		echo '<link rel="canonical" href="' . esc_url( home_url( '/' ) ) . '">' . "\n";
	} elseif ( is_singular() ) {
		echo '<link rel="canonical" href="' . esc_url( get_permalink() ) . '">' . "\n";
	}
	?>
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<header class="site-header">
	<div class="container">
		<!-- Logo (SVG from InfinityLogo.tsx: smooth infinity, solid fill) -->
		<a href="<?php echo esc_url( home_url( '/' ) ); ?>" class="site-logo" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?> home">
			<span class="logo-icon">
				<svg width="44" height="24" viewBox="0 0 80 44" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img">
					<path d="M40 22 C40 22 32 6 20 6 C10.5 6 4 13 4 22 C4 31 10.5 38 20 38 C32 38 40 22 40 22 C40 22 48 6 60 6 C69.5 6 76 13 76 22 C76 31 69.5 38 60 38 C48 38 40 22 40 22Z" fill="#1B4D5C"/>
				</svg>
			</span>
			<span class="logo-text">
				<span class="site-name"><?php echo esc_html( get_bloginfo( 'name' ) ); ?></span>
				<span class="tagline">REST EASY.</span>
			</span>
		</a>

		<?php /* These links will be replaced by a WordPress nav menu (wp_nav_menu). */ ?>
		<!-- Desktop Nav -->
		<nav class="site-nav" aria-label="Main navigation">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a>
			<a href="#">The Property</a>
			<a href="#">How It Works</a>
			<a href="#">Why Restwell?</a>
			<a href="#">Accessibility</a>
			<a href="#">FAQ</a>
			<a href="#">Enquire</a>
		</nav>

		<!-- Mobile Menu Button (toggle will be wired up in main.js) -->
		<button
			type="button"
			class="mobile-menu-btn"
			aria-expanded="false"
			aria-controls="mobile-nav"
			aria-label="Open menu"
		>
			<svg class="js-menu-icon-open" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
			<svg class="js-menu-icon-close" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
		</button>
	</div>

	<?php /* Mobile nav: same links as desktop; will be toggled via JS and eventually replaced by wp_nav_menu. */ ?>
	<!-- Mobile Nav -->
	<nav id="mobile-nav" class="mobile-nav" aria-label="Mobile navigation">
		<div class="container">
			<a href="<?php echo esc_url( home_url( '/' ) ); ?>">Home</a>
			<a href="#">The Property</a>
			<a href="#">How It Works</a>
			<a href="#">Why Restwell?</a>
			<a href="#">Accessibility</a>
			<a href="#">FAQ</a>
			<a href="#">Enquire</a>
		</div>
	</nav>
</header>
