<?php
/**
 * Main template file. Fallback for all templates.
 *
 * @package Restwell_Retreats
 */

get_header();
?>

<?php
get_footer();
